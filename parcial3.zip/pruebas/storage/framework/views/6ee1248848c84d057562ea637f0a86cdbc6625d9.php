<form action="<?php echo e(route('clientes.store')); ?>" method="post">
    <?php echo $__env->make('templates.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form><?php /**PATH /home/ismaniacs/Documentos/tpi/laravel/pruebas/resources/views/create.blade.php ENDPATH**/ ?>