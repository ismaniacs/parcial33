<form action="{{route('clientes.store')}}" method="post">
    @include('templates.form')
</form>